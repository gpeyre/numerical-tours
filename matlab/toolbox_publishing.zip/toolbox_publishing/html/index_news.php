<?
begin_news();
news_display('12/08/15', 'New tour: L1 regularization with homotopy algorithm', 'sparsity_1_homotopy');
news_display('12/08/13', 'New tour: Optimal transport with sliced Wasserstein distance', 'optimaltransp_4_matching_sliced');
news_display('12/08/12', 'New tour: Optimal transport in 1-D', 'optimaltransp_3_matching_1d');
news_display('12/07/11', 'New tour: Optimal transport with Benamou-Brenier algorithm', 'optimaltransp_2_benamou_brenier');
news_display('12/05/23', 'New tour: Optimal transport with linear programming', 'optimaltransp_1_linprog');
news_display('12/05/10', 'New tour: Newton algorithm for optimization', 'optim_2_newton');
end_news();
?>
